#![no_std] // 不使用标准库
#![no_main] // 不使用预定义入口点
#![allow(dead_code, unused_variables)] // 忽略dead_code

use core::arch::global_asm; // 导入需要的Module

mod panic;
mod uart_console;
mod interrupts;
mod pl061;

global_asm!(include_str!("start.s"));

#[no_mangle] // 不修改函数名
pub extern "C" fn not_main() {
    println!("\n[0] Hello from Rust!\n");
    interrupts::init_gicv2();
}
