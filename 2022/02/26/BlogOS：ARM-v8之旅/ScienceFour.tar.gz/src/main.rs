#![no_std] // 不使用标准库
#![no_main] // 不使用预定义入口点

use core::{arch::global_asm, ptr}; // 导入需要的Module

mod panic;
mod uart_console;
mod interrupts;

global_asm!(include_str!("start.s"));

#[no_mangle] // 不修改函数名
pub extern "C" fn not_main() {
    // const UART0: *mut u8 = 0x0900_0000 as *mut u8;
    // let out_str = b"AArch64 Bare Metal";
    // for byte in out_str {
    //     unsafe {
    //         ptr::write_volatile(UART0, *byte);
    //     }
    // }
    // // print_something(); // 调用测试函数
    // println!("\n[0] Hello from Rust!");
    interrupts::init_gicv2();
}

// include!("uart_console.rs");
// use core::fmt;

// pub fn print_something() {
//     // 一定要引用core::fmt::Write;否则报错：no method named `write_fmt` found for struct `Writer` in the current scope。
//     pub use core::fmt::Write;

//     let mut writer = Writer {};
//     let display: fmt::Arguments = format_args!("hello arguments!\n");

//     writer.write_string("\n-----My writer-----\n");
//     writer.write_byte(b'H');
//     writer.write_string("ello ");
//     writer.write_string("World!\n");
//     writer.write_string("[0] Hello from Rust!\n");

//     // 通过实现core::fmt::Write自动实现的方法
//     writer.write_fmt(display).unwrap();
//     // 使用write!宏
//     write!(writer, "The numbers are {} and {} \n", "42", "1.0").unwrap();

//     writer.write_string("-----My writer-----");
// }